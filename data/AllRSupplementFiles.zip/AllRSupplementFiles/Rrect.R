# Approximates the area under the function f over a 
#   given interval
# Make sure the file f.R is contained in the same folder
#   as this file
source("f.R")

# Input: xmin = left end of interval
#        xmax = right end of interval
#        n = how many rectangles to use

# Output: sum = approx of the area under f over a
#               given interval

Rrect = function(xmin, xmax, n) {

# Initially set sum to zero
sum = 0

# Calculate the width of the rectangles
deltax = (xmax - xmin) / n

# One pass through the for loop for each rectangle
for (i in 1:n) {
   # Add onto the current sum the area of the current triangle
   sum = sum + f(xmin + i*deltax) * deltax
   }

return(sum)
}
