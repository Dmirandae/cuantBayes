# function outcome = coinflips(N)
#
# Input:
#  N = number of times to flip the coin
#
# Output:
#  outcome = array with structure
#    [# heads flipped, # tails flipped]
#
coinflips = function(N){
   
   # Get N random numbers in (0, 2)
   x = 2*runif(N)

   # Initialize heads and tails counters to zero
   Hcount = 0
   Tcount = 0

   # For each random number, decide if it is a head or tail
   for (i in 1:N){
      if (floor(x[i]) == 0) {
         Hcount = Hcount + 1
         } else {
         Tcount = Tcount + 1
         }
      }
   
   # Record outcome
   outcome = c(Hcount, Tcount)
   return(outcome)
   }



