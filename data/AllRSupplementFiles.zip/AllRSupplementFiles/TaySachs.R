# Filename: TaySachs.R
# R script for determining P(A|not B) where
#   A = offspring is a carrier
#   B = offspring does have TaySachs
# given that both parents are carriers

# We'll need the function from OneChild.R
source("OneChild.R")

# Set how many times to run the experiment
N = 1000

# Set variables to sum up the probabilities of events
A = 0       # probability of Aa or aA
B = 0       # probability of aa

# Run set of N experiments N times
for (i in 1:N) {
   # Set counters
   a = 0    # heterozygous counter
   b = 0    # homozygous recessive counter

   # Run experiment N times
   for (j in 1:N) {
      # Get child's genotype if both parents are carriers
      child = OneChild(1,1)

      # Increase appropriate counter
      if (child == 1) {
         a = a + 1
         } else if (child == 3) {
         b = b + 1
         } else {
         # do nothing
         }
      }

   # Add the probabilities for this set of N experiments
   # to the running sum
   A = A + a/N
   B = B + b/N
   }

# Estimated Probability of Event A
PA = A/N

# Estimated Probability of Event NOT B
PB = 1 - B/N

# Print out results
cat(sprintf("P(carrier|no disease)=%6.4f", PA/PB), "\n")
