# Hawk Waiting Times

# Generate a sample of 10 waiting times
T = -0.5 * log(1 - runif(10))

# Calculate times of sightings
S = 5 + cumsum(T)

# Display waiting times in terms of hours and minutes
cat("\nWaiting Times  //  Sighting Times\n")
cat("               //   5:00  \n")
for (i in 1:length(T)) {
   cat(sprintf("%2.f h  %2.f min", floor(T[i]),
       round((T[i]*60)%%60)))
   cat(sprintf("   //  "))
   cat(sprintf("%2.f:%02.f", floor(S[i]),
       round((S[i]*60)%%60)), "\n")
   }

# Calculate and print mean waiting time in minutes
meanT = mean(T*60)
cat(sprintf("\nMean waiting time is %4.1f minutes\n\n",
    meanT))

# Generate a random time at which the birder shows up
R = runif(10)*(S[length(S)]-5)+5

# Generate an array to contain time of next sighting
D = numeric(length(R))

# For each birder, find the time of the next hawk
#   sighting
for (i in 1:length(R)) {
   v = min(S[S>R[i]])  #time of next sighting
   D[i] = v - R[i]     #time of next sighting - time of
                       #birder arrival
   }

# Display arrival and waiting times
cat("10 Birders randomly show up\n")
cat("\nArrival Times  //  Waiting Times\n")
for (i in 1:length(T)) {
   cat(sprintf("   %02.f:%02.f", floor(R[i]),
       round((R[i]*60)%%60)))
   cat("       //    ")
   cat(sprintf("%3.f min\n", D[i]*60))
   }

# Calculate and print mean waiting time in minutes of
# the 10 birders
meanD = mean(D*60)
cat("\nMean waiting time of 10 random birders")
cat(sprintf(" is %4.1f minutes\n\n", meanD))
