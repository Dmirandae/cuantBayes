# Approximates the derivative of the function f
# Make sure that the file f.R is contained in the same folder
#   as this file
source("f.R")

# Input: x = value at which you want to find the derivative
#        h = how close you want to get to the limit (h -> 0)

# Output: LLD = limit of the difference equation from
#               the left side
#         RLD = limit of the difference equation from
#               the right side

derivative = function(h,x) {

# left limit
LLD = (f(x+h) - f(x)) / h

# right limit
RLD = (f(x-h) - f(x)) / (-h)

# Return LLD and RLD
return(c(LLD, RLD))
}
