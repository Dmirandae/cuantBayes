# Filename: Bluefish.R
# R script to
#    - enter bluefish data
#    - rescale bluefish data
#    - compute equation for least squares regression line
#    - plot least squares regression line on a graph with the data
#    - compute the correlation coefficient
# LSR = Least Squares Regression

# Enter year array
year = seq(1940, 1990, by = 5)
# Rescale year array to get x data
x = (year - 1940)/5

# Enter pounds of bluefish caught
y = c(15000,
   150000,
   250000,
   275000,
   270000,
   280000,
   290000,
   650000,
   1200000,
   1500000,
   2750000)

# Find the equation for the LSR line
C = lm(log(y)~x)
# Display the equation
cat(sprintf("Eqn for LSR: ln y = %f x + %f", coef(C)[2],
    coef(C)[1]), "\n")

# Find the lnyhat value for each x value
lnyhat = predict(C, data.frame(x))

# Plot the data and the LSR line
plot(x,log(y),
   pch  = 20,
   xlab = "Year (rescaled)",
   ylab = "ln(Pounds of bluefish caught)",
   xlim = c(min(x)-1, max(x)+1),
   ylim = c(min(log(y))-1, max(log(y))+1))
par(new = TRUE)
plot(x, lnyhat,
   type = "l",
   xlab = "",
   ylab = "",
   xlim = c(min(x)-1, max(x)+1),
   ylim = c(min(log(y))-1, max(log(y))+1),
   xaxt = "n",
   yaxt = "n")

# Find the correlation coefficient
rho = cor(x,log(y))
# Display the correlation coefficient
cat(sprintf("rho = %f", rho), "\n")
