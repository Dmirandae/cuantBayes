# R script for rolling a die

# Generate a random number in (0,6)
x = 6*runif(1)

# Print out result
cat(sprintf("You rolled a %d.", ceiling(x)), "\n")
