# R-script to create Female Black Bear Histogram
 
# Enter data
w = c(60, 85, 95, 85, 115, 75, 140, 145, 120, 110, 90, 115, 
75, 125, 80, 80, 80, 110, 75, 120, 150, 38, 118)
 
# Calculate range
range = max(w)-min(w)
 
# Calculate class width
cw = ceiling(range/6)
 
# Determine values where bars should start
startvals = seq(min(w)-0.5,min(w)-0.5+6*cw,by=cw)
 
# Make Histogram with labels
hist(w,
     breaks = startvals,
     xlab = "Female Black Bear Weight (lbs)",
     ylab = "# of Female Black Bears",
     xlim = c(min(w)-0.5,min(w)-0.5+6*cw),
     xaxt = "n")
axis(1,
     at = startvals)
