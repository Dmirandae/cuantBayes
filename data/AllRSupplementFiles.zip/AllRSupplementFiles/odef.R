# Load the package:
require(deSolve)

# Declare your parameters if there are any
a = 1
parms = c(a)

# Declare initial conditions
x_0 = 0
y_0 = 1
start = c(x_0, y_0)

# Write the model
odef = function(t, n, parms) {

x = n[1]
y = n[2]

with(as.list(parms),
{
   # Write the differential equations
   dx = 1
   dy = a*x*y
   
   res = c(dx, dy)

   list(res)
   })
}

# Declare times
times = seq(x_0, 1, by = 0.01)

# Solve the model using rk4 (a 4th-order Runge-Kutta method)
output = as.data.frame(rk4(start, times, odef, parms))

# Take a look at the names of the labels that rk4 
# automatically creates
names(output)

# We want to plot the second column, "2"
plot(output$"2",
   type = "l",
   col = "blue",
   ylab = "y(x)",
   xlab = "x",
   ylim = c(0, 3.5),
   xaxt = "n")
axis(1,                          # The horizontal axis
   at = seq(0, 100, by = 20),    # These are the current labels
   labels = seq(0, 1, by = 0.2)) # Change them to these
   
