# Filename: LogisticDifferenceEqn
# R script to simulate the logistic difference equation

# Set the values of r and x0
r = 0.8
x0 = 0.2

# Through the loop we will fill the values x_n into the array x.
# In the first iteration of the loop, the value of x[1] needs to 
# be known.  We set that value before starting the loop
x = numeric()
x[1] = x0

for (n in 1:50) {
   x[n+1] = x[n] + r*x[n]*(1-x[n])
   }

# Plot the results
plot(x,
     type = "b",
     pch = c(20),
     xlab = "Time Step",
     ylab = "Population  Density",
     main = "")
