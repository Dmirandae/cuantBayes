# Creates the function f(x)
# Input: x (a real number)
# Output: y

f = function(x) {
return((sqrt(x^2+9)-3)/(x^2))
}
