# Find the limit of a function f
# Make sure f.m is contained in the same folder as this file

# Input: x = value at which you want to find the limit
#        delta = how close do you want to get to the value x

# Output: LL = limit from the left side
#         RL = limit from the right side

# Make sure we have f.R loaded
source("f1.R")

limit = function(h,x) {

# Left limit
LL = f(x - h)

# Right limit
RL = f(x + h)

return(c(LL, RL))
}
