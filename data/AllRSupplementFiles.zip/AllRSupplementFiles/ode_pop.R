# Load the package:
require(deSolve)

# Declare your parameters if there are any
a = 0.25
parms = c(a)

# Declare initial conditions
y_0 = 50
start = c(y_0)

# Write the model
odef = function(t, n, parms) {

y = n[1]

with(as.list(parms),
{
   # Write the differential equations
   dy = a * y * log(1000/y)
   
   res = c(dy)

   list(res)
   })
}

# Declare times
times = seq(0, 20, by = 0.01)

# Solve the model using rk4 (a 4th-order Runge-Kutta method)
output = as.data.frame(rk4(start, times, odef, parms))

# Prepare to add in a legend
par(mar = c(5.1, 4.1, 4.1, 11.1), xpd = TRUE)

# Take a look at the names of the labels that rk4 
# automatically creates
names(output)

# We want to plot the first column, "1"
plot(output$"1",
   type = "l",
   col  = c(1),
   ylim = c(0, 1500),
   ylab = "y(t)",
   xlab = "t",
   xaxt = "n")
axis(1,                         # The horizontal axis
   at = seq(0, 2000, by = 500), # These are the current labels
   labels = seq(0, 20, by = 5)) # Change them to these

# Vector of initial conditions
y_0 = c(100, 500, 1000, 1500)

# For-loop
for (i in 1:length(y0)) {
   # Re-set start each time
   start = c(y_0[i])

   # Solve the ODE
   output = as.data.frame(rk4(start, times, odef, parms))
   
   # Plot our values on the same graph
   par(new = TRUE)
   plot(output$"1",
      type = "l",
      col  = c(i+1),
      ylim = c(0, 1500),
      ylab = "",
      xlab = "",
      xaxt = "n",
      yaxt = "n")
   }

legend("right",
   inset = c(-0.41, 0),
   lty = c(1, 1, 1, 1, 1),
   c("50", "100", "500", "1000", "1500"),
   col = c(1, 2, 3, 4, 5))

