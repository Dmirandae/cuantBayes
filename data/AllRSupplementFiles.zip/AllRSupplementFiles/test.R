# This is a comment in an R script.  Anything typed after
# the pound sign in an R script will not be read as a
# command.  This allows you to put comments and notes in
# your R scripts.

x = seq(0, 10, by = 2.5)      # Enter some vector

m = length(x)                 # Find the length of x
