# Creates the function f(x)
# Input: x (a real number)
# Output: y

f = function(x) {
if (x <= 2) {
   y = x^2
   } else {
   y = 3*x + 2
   }

return(y)
}
