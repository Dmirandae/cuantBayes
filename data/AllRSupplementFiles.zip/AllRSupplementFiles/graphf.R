# Create a graph of f
# Make sure f.R is contained in the same folder as this file
# Inputs: xmin = minimum x value to graph
#         xmax = maximum x value to graph
# Output: a graph

# Load f.R
source("f.R")

graphf = function(xmin,xmax) {

# Create 1000 x values to graph
n = (xmax - xmin) / 1000
x = seq(xmin, xmax, by = n)

# Construct an array to hold f(x) values
F = numeric(length(x))

# Create 1000 f(x) values to graph
for (i in 1:length(x)) {
   F[i] = f(x[i])
   }

# Create plot
plot(x, F,
   col = "red",
   type = "l",
   xlab = "x",
   ylab = "f(x)")
}
