# Filename: MammalPulseRates.R
# R script to
#    - enter mammal pulse rates data
#    - calc. correlation coeff. for y vs x
#    - calc. correlation coeff. for ln y vs x
#    - calc. correlation coeff. for ln y vs ln x

# Enter the data
x = c(4,
   25,
   200,
   300,
   2000,
   5000,
   30000,
   50000,
   70000,
   450000,
   500000,
   3000000) # body weight data
y = c(660,
   670,
   420,
   300,
   205,
   120,
   85,
   70,
   72,
   38,
   40,
   48) # pulse rate data

# Calculate correlation coeff. for y vs x
rho = cor(x,y)
# Display the correlation coefficient
cat(sprintf("(x, y)          rho = %f", rho), "\n")

# Calculate correlation coeff. for ln y vs x
rho = cor(x, log(y))
# Dsplay the correlation coefficient
cat(sprintf("(x, ln y)       rho = %f", rho), "\n")

# Calculate correlation coeff. for ln y vs ln x
rho = cor(log(x), log(y))
# Display the correlation coefficient
cat(sprintf("(ln x, ln y)    rho = %f", rho), "\n")
