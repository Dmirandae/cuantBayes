# Filename: MinMax.R
# R script to
#  - calculate the minimum & maximum of an array
#  - display t hat min and max

# Create array
x = c(20, 45, 81, 6, -3, -23, 99)

# Find minimum and maximum of array
minx = min(x)
maxx = max(x)

# Display the min & max using cat and sprintf
cat(sprintf("The max is %d\n", maxx))
cat(sprintf("The min is %d\n", minx))
cat(sprintf("The average of the min and max is %4.1f\n",
    (maxx+minx)/2))
