# function out = DrugTesting
# Inputs: none
#
# Output:
#   out = 1x2 matrix representing results for 1 individual
#     column 1: 0 = sugar pill, 1 = sleeping pill
#     column 2: 0 = no improved sleep, 1 = improved sleep

DrugTesting = function() {

# Create matrix of drug testing results
Results = matrix(rep(0, 200*2), ncol = 2)

# Set first 1/2 of column 1 to "took sleeping pill"
Results[1:100,1] = 1
# Set first 71 of column 2 to "improved sleep"
Results[1:71,2] = 1
# Now rows 1-71 = "took sleeping pill" & "had improved sleep"
# and rows 72-100 = "took sleeping pill" & "no improved sleep"

# Set rows 101-158 of column to "improved sleep"
Results[101:158,2] = 1
# Now rows 101-158 = "took sugar pill" & "had improved sleep"
# and rows 159-200 = "took sugar pill" & "no improved sleep"

# Randomly pick one of the 200 individuals
x = ceiling(200*runif(1))  # generates intengers from 1 to 200

# Create function output
return(Results[x,])
}
