# Cricket Chirping Data
T = c(69.4, 69.7, 71.6, 75.2, 76.3, 79.6, 80.6,
      82.0, 82.6, 83.3, 83.5, 84.3, 88.6, 93.3)
C = c(15.4, 14.7, 16.0, 15.5, 14.4, 15.0, 16.6,
      17.1, 17.2, 16.2, 17.0, 18.4, 20.0, 19.8)

# Construct an array to store rate of change info
RoC = numeric(length(T)-2)

# Estimate rates of change at each point (not including
#   end points)
for (i in 2:(length(T)-1)) {
   # Average rate of change from i-1 to i
   L = (C[i] - C[i-1]) / (T[i] - T[i-1])

   # Average rate of change from i to i+1
   R = (C[i+1] - C[i]) / (T[i+1] - T[i])

   # Estimate rate of change at i
   RoC[i] = (L+R)/2
   }

# Plot out data
pdf('CricketChirpsD.pdf')
par(mfrow = c(2,1))
plot(T, C,
   col = "blue",
   xlab = expression(paste("Temperature ",degree,"F")),
   ylab = "Chirps/second")

# Plot out rate of change information
plot(T[2:(length(T)-1)], RoC[2:(length(T)-1)],
   type = "b",
   pch = 21,
   col = "green",
   xlab = expression(paste("Temperature ",degree,"F")),
   ylab = expression(paste("Chirps/second/",degree,"F")))
dev.off()
