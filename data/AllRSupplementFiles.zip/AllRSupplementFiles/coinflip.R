# R script for flipping a coin

# Generate a random number in (0,2)
x = 2*runif(1)

# Determine if heads or tails
if (floor(x) == 0) {
   cat("Your coin landed head side up!\n")
   } else {
   cat("Your coin landed tail side up!\n")
   }
