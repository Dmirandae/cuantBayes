# Approximates the area under the function f over 
#   a given interval
# Make sure the file f.R is contained in the same
#   folder as this file
source("f.R")

# Input: xmin = left end of interval
#        xmax = right end of interval
#        n = how many trapezoids to use

# Output: sum = approx of the area under f over a 
#               given interval

Trap = function(xmin, xmax, n) {

# Initially set sum to zero
sum = 0

# Calculate the width of the rectangles
deltax = (xmax - xmin) / n

# One pass through the for loop for each trapezoid
for (i in 0:(n-1)) {
   # Add onto the current sum the area of the current
   # trapezoid
   sum = sum + 
         (f(xmin + i*deltax) +
         f(xmin + (i+1)*deltax))/2 * deltax
   }

return(sum)
}
