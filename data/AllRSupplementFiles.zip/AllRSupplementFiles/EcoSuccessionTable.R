# Filename: EcoSuccessionTable.R
# R script to
# - Print out a table showing landscape structure over time

# A function to perform matrix exponentiation
"%^%"<-function(A,n){ 
  if(n==1) A else {B<-A; for(i in (2:n)){A<-A%*%B}}; A 
  } 

# Enter the transfer matrix
T = matrix(c( 0.94, 0.05, 0.01,
              0.02, 0.86, 0.12,
              0.01, 0.06, 0.93 ), ncol = 3)

# Enter the initial state
x0 = matrix(c( 1, 0, 0 ), ncol = 1)

# Print header for table
cat(" t      u      s      d\n")
cat("-------------------------\n")

# Fill in table using a for loop
for (t in c(1, 2, 3, 4, 5, 10, 20, 30, 40, 50, 100, 200)){
   x = T%^%t %*% x0        # matrix multiplication
   u = x[1,1]              # get u value for this time step
   s = x[2,1]              # get s value for this time step
   d = x[3,1]              # get d value for this time step
   cat(sprintf("%3d  %5.3f  %5.3f  %5.3f",t,u,s,d),"\n")
   }
