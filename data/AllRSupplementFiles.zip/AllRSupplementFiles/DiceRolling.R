# Filename: DiceRolling
# R script to compute probability of rolling doubles or 
#    a sum of 6.

# Number of times to run experiment
N = 1000

# Initialize sum of probabilities
C = 0

for (i in 1:N) {
   # Set event counter to zero
   c = 0

   for (j in 1:N) {
      # Roll two dice x and y
      x = ceiling(6*runif(1))
      y = ceiling(6*runif(1))

      # If roll doubles or sum 6, increase counter.
      # Otherwise do nothing
      if ((x == y) || (x + y == 6)) {
         c = c + 1
         }
      }

   # Add on prob of event after rolling N times
   C = C + c/N
   }

# Print out result
cat(sprintf("P(doubles OR sum of 6) = %6.4f", C/N), "\n")
