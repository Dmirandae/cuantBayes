# Cricket Chirping Data
T = c(69.4, 69.7, 71.6, 75.2, 76.3, 79.6, 80.6, 80.6,
      82.0, 82.6, 83.3, 83.5, 84.3, 88.6, 93.3)
C = c(15.4, 14.7, 16.0, 15.5, 14.4, 15.0, 16.0, 17.1,
      17.1, 17.2, 16.2, 17.0, 18.4, 20.0, 19.8)

# Plot out data
plot(T, C,
   xlab = expression(paste("Temperature ",degree,"F")),
   ylab = "Chirps/second")
# Plot LSR
mod = lm(C~T)
abline(mod,
   col = "red")

# Display the equation
cat(sprintf("Eqn for LSR: C(T) = %f T + %f",
   coef(mod)[2], coef(mod)[1]), "\n")

# Average rate of change in chirps/sec as temp goes
#    from 70 to 80
f = function(x) {
return(coef(mod)[2] * x + coef(mod)[1])
}

avg = (f(80) - f(70))/(80 - 70)
cat(sprintf("[C(80)-C(70)]/[80-70] = %f chirps/sec/degree F",
   avg), "\n")


