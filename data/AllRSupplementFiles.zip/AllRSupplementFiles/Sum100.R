# Filename: Sum100.R
# R script to
# - Sum the numbers 1 to 100

total = 0                # initial total to 0
for (i in 1:100){        # loop through 1, 2, ..., 100
   total = total + i     # add next value to total
   }
cat(sprintf("total = %i", total), "\n")
