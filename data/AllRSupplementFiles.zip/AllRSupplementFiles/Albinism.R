# Filename: Albinism.R
# R script for determining the probability of child with two
#   albinism carrying parents
# The possible outcomes for the child are
#   (a) an albinism carrier (Aa, aA)
#   (b) have no albinism alleles (AA)
#   (c) albino (aa)
# This file finds the probability of each outcome.

# Set how many times to run the experiment
N = 1000

# Set variables to sum up probabilities
A = 0      # sum of heterozygous probabilities
B = 0      # sum of homozygous dominant probabilities
C = 0      # sum of homozygous recessive probabilities

for (i in 1:N) {
   # Set counters
   a = 0   # heterozygous counter
   b = 0   # homozygous dominant counter
   c = 0   # homozygous recessive probabilities

   for (j in 1:N) {
      # Get child's genotype if both parents are carriers
      child = OneChild(1,1)

      # Increase appropriate counter
      if (child == 1) {
         a = a + 1
         } else if (child == 2) {
         b = b + 1
         } else {
         c = c + 1
         }
      }
   
   # Add the probabilities for this set of N experiments
   # to the running sum
   A = A + a/N
   B = B + b/N
   C = C + c/N
   }

# Print out results
cat(sprintf("P(carrier of albinism) = %6.4f", A/N), "\n")
cat(sprintf("P(has albinism) = %6.4f", C/N), "\n")
cat(sprintf("P(no recessive alleles) = %6.4f", B/N), "\n")


