# Filename: ProbHeadFlip.R
# R script to compute probability of flipping a heads

# Number of times to collect output
n = 500

# Initialize heads count
Hcount = 0

# Run coinflips n times
for (i in 1:n){
   # Coinflips will run 1000 experiments each time
   output = coinflips(1000)

   # sum up number of heads outputs
   Hcount = Hcount + output[1]
   }

# Compute average number of heads
Haverage = Hcount / 1000

# Estimate probability of flipping heads
ProbH = Haverage / n

# Print out answer
cat(sprintf("P(Heads) = %6.4f", ProbH), "\n")
