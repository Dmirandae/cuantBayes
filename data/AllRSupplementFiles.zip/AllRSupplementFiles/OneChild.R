# function child = OneChild(mom,dad)
#
# Inputs:
#   mom = genotype of mother**
#   dad = genotype of father**
# ** For genotypes use
#     1 for heterozygous, Aa or aA
#     2 for homozygous dominant, AA
#     3 for homozygous recessive, aa
#
# Output:
#   child = genotype of offspring
OneChild = function(mom,dad){

# Within this function we will use
#   0 to represent a recessive allele
#   1 to represent a dominant allele

# Determine allele inherited from mother
if (mom == 1) {
   # if mom heterozygous, randomly choose between two alleles
   childallele1 = floor(2*runif(1))
   } else if (mom == 2) {
   # if mom homozygous dominant, then child inherits A
   childallele1 = 1
   } else {
   # if mom homozygous recessive, then child inherits a
   childallele1 = 0
   }

# Determine allele inherited from father
if (dad == 1) {
   # if dad heterozygous, randomly choose between two alleles
   childallele2 = floor(2*runif(1))
   } else if (dad == 2) {
   # if dadm homozygous dominant, then child inherits A
   childallele2 = 1
   } else {
   # if dad homozygous recessive, then child inherits a
   childallele2 = 0
   }

# Determine the genotype of the child
if ((childallele1 == 1) && (childallele2 == 1)) {
   child = 2
   } else if ((childallele1 == 0) && (childallele2 == 0)) {
   child = 3
   } else {
   child = 1
   }

# Return the genotype
return(child)
}
