# function child = OneChild2Genes(mom,dad)
#
# Inputs:
#   mom = genotype of mother**
#     array containing genotype of first & second genes
#   dad = genotype of father**
#     array containing genotype of first & second genes
# ** For genotypes use
#     1 for heterozygous, Aa or aA
#     2 for homozygous dominant, AA
#     3 for homozygous recessive, aa
#
# Output:
#   child = genotype of offspring array containing
#     genotype for first gene and second gene

OneChild2Genes = function(mom, dad) {

# Within this function we will use
#   0 to represent a recessive allele
#   1 to represent a dominant allele

# Declare an array to store the genotypes
child = numeric(2)

# Loop through both genes
for (i in 1:2) {
   # determine allele for gene i from mother
   if (mom[i] == 1) {
      # if mom heterozygous, randomly choose between two alleles
      childallele1 = floor(2*runif(1))
      } else if (mom[i] == 2) {
      # if mom homozygous dominant, then child inherits A
      childallele1 = 1
      } else {
      # if mom homozygous dominant, then child inherits a
      childallele1 = 0
      }

   # determine allele for gene i from father
   if (dad[i] == 1) {
      # if dad heterozygous, randomly choose between two alleles
      childallele2 = floor(2*runif(1))
      } else if (dad[i] == 2) {
      # if dad homozygous dominant, then child inherits A
      childallele2 = 1
      } else {
      # if dad homozygous dominant, then child inherits a
      childallele2 = 0
      }

   # Determine the genotype of the child for gene i
   if ((childallele1 == 1) && (childallele2 == 1)) {
      child[i] = 2
      } else if ((childallele1 == 0) && (childallele2 == 0)) {
      child[i] = 3
      } else {
      child[i] = 1
      }
   }

# Return statement
return(child)
}
