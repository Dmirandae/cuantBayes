# Filename: SleepingPillEfficacy.R
# R script to estimate probability of sleeping better given
#   that you take a sleeping pill

# Set how many times to run the experiment
N = 1000

# Set variables to sum up the probabilities of events
A = 0    # probability took sleeping pill
B = 0    # probability took sleeping pill + had improved sleep

# Run set of N experiments N times
for (i in 1:N) {
   # Set counters
   a = 0   # took sleeping pill counter
   b = 0   # took sleeping pill + had improved sleep counter

   # Run experiment N times
   for (j in 1:N) {
      # Select one participant
      x = DrugTesting()

      # If participant took sleeping pill
      if (x[1] == 1) {
         a = a + 1
         
         # If participant also had improved sleep
         if (x[2] == 1) {
            b = b + 1
            }
         }
      }

   # Add the probabilities for this set of N experiments
   # to the running sum
   A = A + a/N
   B = B + b/N
   }

# Print out result
cat(sprintf("P(improved sleep|took sleeping pill) 
   = %6.4f", (B/N)/(A/N)), "\n")
